import React from 'react'

const Shares = () => {
  return (
    <div>Shares</div>
  )
}

export default Shares