import React from "react";

const PaymentPlan = () => {
  return (
    <div>PaymentPlan</div>
  )
}

export default PaymentPlan